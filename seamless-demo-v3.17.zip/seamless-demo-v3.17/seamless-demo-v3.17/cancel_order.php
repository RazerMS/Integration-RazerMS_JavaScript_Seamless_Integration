<?
//echo "<pre>".print_r($_POST,1)."</pre>";
echo "You have cancelled order. Thank you";
exit;
?>